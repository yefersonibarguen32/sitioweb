<?php include("template/cabecera.php");?>


<div class="jumbotron">
    <h1 class="display-3">Nosotros</h1>
    <p class="lead">Hola somos tu tienda virtual Tenismedellin_96</p>
    <hr class="my-2">

    </div>
<?php include("template/pie.php");?>