<?php include("template/cabecera.php");?>
    <div class="jumbotron text-center">
        <h1 class="display-3">Tu tienda virtual</h1>
        <p class="lead">Tenismedellin_99</p>
        <hr class="my-2">
        
<img width="400" src="img/jordan.png" class="img-thumbnail rounded mx-auto d-block" />


        <p class="lead">
            <a class="btn btn-primary btn-lg" href="productos.php" role="button">Ver catalogo</a>
        </p>
    </div>
    
    <?php include("template/pie.php");?>

